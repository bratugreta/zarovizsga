function osszesOszto(szam) {
    var osszesOszto = [];
    var oszto = 2;
    var egyOszto = 1;
    osszesOszto.push(egyOszto);
    while (oszto <= szam) {
        if (szam % oszto == 0) {
            osszesOszto.push(oszto);
            oszto++;
        }
        else {
            oszto++;
        }
    }
    return osszesOszto;
}
function parosDarab(szamok) {
    var parosDB = 0;
    for (var i = 0; i < szamok.length; i++) {
        if (szamok[i] % 2 == 0) {
            parosDB++;
        }
    }
    return parosDB;
}
function fuggvenyhivasPalindrom(szoveg) {
    var szoveg = function (fuggveny) {
        fuggveny = fuggveny.trim();
        fuggveny = fuggveny.replaceAll(" ", "");
        fuggveny = fuggveny.toLowerCase();
    };
    var palindromE = false;
    for (var i = 0; i < szoveg.length / 2; i++) {
        if (szoveg[i] !== szoveg[length - 1 - i]) {
            palindromE = false;
        }
        else {
            palindromE = true;
        }
        return palindromE;
    }
}
