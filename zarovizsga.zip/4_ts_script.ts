function osszesOszto(szam:number):number[]{
    var osszesOszto: number[] = [];
    var oszto: number = 2;
    var egyOszto: number = 1;
    osszesOszto.push(egyOszto);

    while(oszto <= szam){
        if(szam % oszto == 0){
            osszesOszto.push(oszto);          
            oszto++;
        }
        else{
            oszto++;
        }
    }

    return osszesOszto; 
}

function parosDarab(szamok:number[]):number{
    
    var parosDB:number = 0;

    for(var i:number = 0; i < szamok.length; i++){
        if(szamok[i] % 2 == 0){
            parosDB++;
        }
    }
    return parosDB;

}


function fuggvenyhivasPalindrom(szoveg:string):boolean{
    var szoveg:string = function(fuggveny):string{
    fuggveny = fuggveny.trim();
    fuggveny = fuggveny.replaceAll(" ", "");
    fuggveny = fuggveny.toLowerCase();
    }
    var palindromE = false;

    for( var i:number = 0; i < szoveg.length/2; i++){
        if(szoveg[i] !== szoveg[length-1-i]){
            palindromE = false;
            
        }
        else{
            palindromE = true;
        }
        return palindromE;
    }
    
    }

